using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NewValue : MonoBehaviour
{

    public Color c;
    public Color c2;
    public Color c3;

    public Image img;
    public Image img2;
    public Image img3;
    public Image img4;


    void Start()
    {
        img.color = c3;
    }
}
